# Synthetic receipt samples v0.1

These files are generated from local synthetic scenarios for parser and UI tests.

They are not real claims and must not be submitted or treated as valid transmission files.

Medical samples use RECEIPTH.UKE-like visit nursing records.
Care samples use 7111/7131-like care claim CSV records.

Run:

```powershell
node scripts/generate_synthetic_receipt_samples.mjs
```
